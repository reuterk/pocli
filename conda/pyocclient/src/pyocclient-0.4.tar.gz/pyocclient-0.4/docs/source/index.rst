.. ownCloud Client documentation master file, created by
   sphinx-quickstart on Sat Apr 26 17:36:06 2014.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

ownCloud client library documentation
=====================================

Contents:

.. toctree::
   :maxdepth: 4

   Description <README>
   API Documentation <owncloud>
   Contributors <CONTRIBUTORS>

Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`

