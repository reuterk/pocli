owncloud.owncloud module
========================

.. automodule:: owncloud.owncloud
    :members:
    :undoc-members:
    :show-inheritance:
