Contributors
============

* Vincent Petry <pvince81@owncloud.com>
* Steffen Lindner <mail@steffen-lindner.de>
* Soal <soal@soal.pl>
* Bruno Santeramo <bruno.santeramo@gmail.com>
* jennifer <jennifer@owncloud.com>
* Sergio Bertolín <sbertolin@solidgear.es>
* Alessandro Cosentino <cosenal@gmail.com>
* Mike <mike@x220>
* Joas Schilling <nickvergessen@owncloud.com>
* Individual IT Services <info@individual-it.net>
* Juan Pablo Villafáñez <jvillafanez@solidgear.es>
* Simon Vigneux <svigneux@kronostechnologies.com>
* Roeland Jago Douma <rullzer@owncloud.com>
* Erik Pellikka <erik@pellikka.org>
* Florian Zierer <florian.zierer@moticon.de>
